public class Test {
    public static void main(String[] args) {
        DatabaseConnector db = new DatabaseConnector();

        //System.out.println(db.getScoreboard(0));




    }
}
